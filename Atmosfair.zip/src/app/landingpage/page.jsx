
import HomeComponent from '@/components/home/home.component'
import React from 'react'

const Page = () => {
    return (
        <HomeComponent />
    )
}

export default Page
