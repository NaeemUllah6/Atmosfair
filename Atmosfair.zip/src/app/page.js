import Landingpage from '@/app/landingpage/page'

const page = () => {
  return (
    <>
   <Landingpage/>
   </>
  )
}

export default page
